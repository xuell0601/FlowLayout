package com.youth.banner.listener;

import android.view.View;

public interface OnBannerClickListener {
    public void OnBannerClick(int position);
}
